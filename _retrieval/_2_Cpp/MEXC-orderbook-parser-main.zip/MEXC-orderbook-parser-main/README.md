# OrderBook Bot

## Описание

Программа подключается к публичному WebSocket API криптовалютной биржи, получает данные OrderBook (стакан заявок) и отправляет их в Telegram с заданным интервалом.

## Возможности

- Поддержка различных бирж (MEXC и др.)
- Поддержка различных торговых пар
- Настраиваемый интервал отправки
- Настраиваемая глубина стакана
- Скорость. Быстрее любого кода на Python благодаря C++, кэшам и многопоточности.

## Структура проекта

```
OrderBook-Bot/
├── CMakeLists.txt          # Файл сборки CMake
├── README.md               # Документация
├── config/                 # Конфигурационные файлы
│   └── config.json.example # Пример конфигурации
├── include/                # Заголовочные файлы
│   ├── exchange/          # Модуль работы с биржами
│   ├── websocket/         # WebSocket клиент
│   ├── telegram/          # Telegram бот
│   ├── orderbook/         # Обработка OrderBook
│   ├── config/            # Конфигурация
│   └── utils/             # Утилиты (логирование, обработка ошибок)
├── src/                    # Исходные файлы
│   ├── exchange/
│   ├── websocket/
│   ├── telegram/
│   ├── config/
│   ├── utils/
│   └── main.cpp           # Главный файл
└── build/                  # Директория сборки (создается автоматически)
```

## Зависимости

- C++17 компилятор (GCC, Clang, MSVC)
- CMake 3.15+
- libcurl (для HTTP запросов к Telegram API)
- nlohmann_json (для парсинга JSON)
- WebSocket библиотека (libwebsockets, websocketpp или другая)

## Сборка

```bash
mkdir build
cd build
cmake ..
cmake --build . -j
```

## Конфигурация

### Через файл

Скопируйте `config/config.json.example` в `config/config.json` и заполните параметры:

```json
{
  "exchange": {
    "name": "MEXC", // Название биржы
    "symbol": "BTC_USDT" // Тикер нужно писать через _
  },
  "telegram": {
    "bot_token": "YOUR_BOT_TOKEN", // Токен бота
    "chat_id": "YOUR_CHAT_ID",  // Чат в ТГ, куда бот будет писать
    "price_precision": 2,       // Количество знаков после запятой для цены
    "quantity_precision": 2,    // Количество знаков после запятой для объёма
    "use_newlines": true        // true = цена и объём на отдельных строках, false = через "|"
  },
  "settings": {
    "update_interval_sec": 60, // Интервал отправки в Telegram (секунды)
    "orderbook_depth": 5,     // Глубина стакана (количество уровней)
    "reconnect_delay_sec": 5, // Задержка перед переподключением (секунды)
    "max_reconnect_attempts": 10 // Максимальное количество попыток переподключения
  },
  "logging": {
    "level": "INFO", // Уровень логирования (DEBUG, INFO, WARNING, ERROR)
    "file": "", // Пустое значение = вывод в stdout
    "enabled": true   // false = отключить логирование. Рекомендуется отключать логирование для прод инсталяций
  }
}
```

Запуск:
```bash
./OrderBookBot ../config/config.json
```

### Через переменные окружения

```bash
export EXCHANGE_NAME=MEXC
export SYMBOL=PEPEUSDT
export TELEGRAM_BOT_TOKEN=your_token
export TELEGRAM_CHAT_ID=your_chat_id
export UPDATE_INTERVAL_SEC=60
export ORDERBOOK_DEPTH=5
export TELEGRAM_PRICE_PRECISION=2
export TELEGRAM_QUANTITY_PRECISION=2
export TELEGRAM_USE_NEWLINES=1
export LOG_LEVEL=INFO
export LOG_FILE=""
export LOG_ENABLED=1

./OrderBookBot

```

## Формат сообщения в Telegram

```
📊 BTC_USDT | [■■■■■■■■■■■■■] | 21:12:54

🟢 BUY (Top 5):
88881.20 | 1.00
88881.10 | 1.00
88881.00 | 1.00
88880.90 | 1.00
88880.80 | 1.00
🔴 SELL (Top 5):
88881.30 | 2.00
88881.40 | 1.00
88881.50 | 1.00
88881.60 | 1.00
88881.70 | 1.00

💰 Spread: 0.10
```

## Расширение функциональности

### Добавление новой биржи

1. Создайте класс, наследующий `ExchangeBase` (например, `BinanceExchange`)
2. Реализуйте все виртуальные методы
3. Добавьте тип биржи в `ExchangeFactory::ExchangeType`
4. Добавьте создание в `ExchangeFactory::create()`

### Изменение формата сообщения

Измените метод `TelegramBot::formatOrderBook()` в `src/telegram/telegram_bot.cpp`

## TODO

- [ ] Реализовать WebSocket клиент
- [ ] Реализовать парсинг JSON для MEXC API
- [ ] Реализовать HTTP POST для Telegram API
- [ ] Добавить поддержку других бирж
- [ ] Добавить unit-тесты
- [ ] Добавить обработку различных типов сообщений от биржи

## Лицензия

TODO
