#include "telegram/telegram_bot.hpp"
#include "utils/logger.hpp"
#include <curl/curl.h>
#include <sstream>
#include <iomanip>
#include <cstring>

namespace orderbook_bot {

struct CurlWriteData {
    char* data;
    size_t size;
};

static size_t curlWriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    size_t realsize = size * nmemb;
    CurlWriteData* mem = static_cast<CurlWriteData*>(userp);
    
    char* ptr = static_cast<char*>(std::realloc(mem->data, mem->size + realsize + 1));
    if (!ptr) {
        return 0;
    }
    
    mem->data = ptr;
    std::memcpy(&(mem->data[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->data[mem->size] = 0;
    
    return realsize;
}

static void escapeJsonString(std::string& str) {
    size_t pos = 0;
    while ((pos = str.find_first_of("\"\\\n\r\t", pos)) != std::string::npos) {
        switch (str[pos]) {
            case '"': str.replace(pos, 1, "\\\""); pos += 2; break;
            case '\\': str.replace(pos, 1, "\\\\"); pos += 2; break;
            case '\n': str.replace(pos, 1, "\\n"); pos += 2; break;
            case '\r': str.replace(pos, 1, "\\r"); pos += 2; break;
            case '\t': str.replace(pos, 1, "\\t"); pos += 2; break;
            default: ++pos; break;
        }
    }
}

TelegramBot::TelegramBot(const std::string& bot_token, const std::string& chat_id)
    : bot_token_(bot_token), chat_id_(chat_id) {
    curl_global_init(CURL_GLOBAL_DEFAULT);
}

TelegramBot::~TelegramBot() {
    curl_global_cleanup();
}

bool TelegramBot::sendOrderBook(
    std::shared_ptr<OrderBook> orderbook,
    const std::string& symbol,
    int tg_price_precision,
    int tg_quantity_precision,
    bool tg_use_newlines,
    int depth
) {
    if (!orderbook || orderbook->isEmpty()) {
        LOG_WARNING("OrderBook is empty, cannot send");
        return false;
    }

    std::string message = formatOrderBook(
        orderbook, 
        symbol, 
        tg_price_precision, 
        tg_quantity_precision, 
        tg_use_newlines, 
        depth
    );
    return sendMessage(message);
}

bool TelegramBot::sendMessage(const std::string& message) {
    std::string endpoint = std::string(API_URL) + bot_token_ + "/sendMessage";
    
    std::string escaped_msg = message;
    escapeJsonString(escaped_msg);
    
    std::ostringstream json;
    json << R"({"chat_id":")" << chat_id_ << R"(","text":")" << escaped_msg << R"("})";
    
    std::string json_data = json.str();
    std::string response = httpPost(endpoint, json_data);
    
    bool success = !response.empty() && response.find("\"ok\":true") != std::string::npos;
    if (!success) {
        LOG_ERROR("Telegram API error: " + response);
    }
    
    return success;
}

std::string TelegramBot::formatOrderBook(
    std::shared_ptr<OrderBook> orderbook,
    const std::string& symbol,
    int tg_price_precision,
    int tg_quantity_precision,
    bool tg_use_newlines,
    int depth
) {
    if (!orderbook) return "";

    thread_local static char buffer[8192];
    char* p = buffer;
    size_t remaining = sizeof(buffer) - 1;

    auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    std::tm tm_now;
    localtime_r(&now, &tm_now);

    char time_buf[16];
    std::strftime(time_buf, sizeof(time_buf), "%H:%M:%S", &tm_now);

    int written = std::snprintf(p, remaining, "📊 %s | [%s] | %s\n\n",
                                symbol.c_str(), "■■■■■■■■■■■■■", time_buf);
    if (written > 0 && static_cast<size_t>(written) < remaining) { p += written; remaining -= written; }

    const char* sep = tg_use_newlines ? "\n" : " | ";

    written = std::snprintf(p, remaining, "🔴 SELL (Top %d):\n", depth);
    if (written > 0 && static_cast<size_t>(written) < remaining) { p += written; remaining -= written; }

    Order asks_buffer[MAX_ORDERBOOK_DEPTH];
    orderbook->getTopAsks(asks_buffer, depth);
    size_t asks_count = std::min(static_cast<size_t>(depth), orderbook->getAsksCount());

    for (size_t i = 0; i < asks_count && remaining > 50; ++i) {
        written = std::snprintf(p, remaining,
            ("%." + std::to_string(tg_price_precision) + "f" + std::string(sep) +
             "%." + std::to_string(tg_quantity_precision) + "f\n").c_str(),
            asks_buffer[i].price, asks_buffer[i].quantity);
        if (written > 0 && static_cast<size_t>(written) < remaining) { p += written; remaining -= written; }
    }

    written = std::snprintf(p, remaining, "\n🟢 BUY (Top %d):\n", depth);
    if (written > 0 && static_cast<size_t>(written) < remaining) { p += written; remaining -= written; }

    Order bids_buffer[MAX_ORDERBOOK_DEPTH];
    orderbook->getTopBids(bids_buffer, depth);
    size_t bids_count = std::min(static_cast<size_t>(depth), orderbook->getBidsCount());

    for (size_t i = 0; i < bids_count && remaining > 50; ++i) {
        written = std::snprintf(p, remaining,
            ("%." + std::to_string(tg_price_precision) + "f" + std::string(sep) +
             "%." + std::to_string(tg_quantity_precision) + "f\n").c_str(),
            bids_buffer[i].price, bids_buffer[i].quantity);
        if (written > 0 && static_cast<size_t>(written) < remaining) { p += written; remaining -= written; }
    }

    if (asks_count > 0 && bids_count > 0) {
        double spread = asks_buffer[0].price - bids_buffer[0].price;
        written = std::snprintf(p, remaining,
            ("\n💰 Spread: %." + std::to_string(tg_price_precision) + "f\n").c_str(), spread);
        if (written > 0 && static_cast<size_t>(written) < remaining) { p += written; remaining -= written; }
    }

    *p = '\0';
    return std::string(buffer);
}


std::string TelegramBot::httpPost(const std::string& endpoint, const std::string& data) {
    CURL* curl = curl_easy_init();
    if (!curl) {
        LOG_ERROR("Failed to initialize CURL");
        return "";
    }
    
    CurlWriteData write_data;
    write_data.data = static_cast<char*>(std::malloc(1));
    write_data.size = 0;
    
    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    
    curl_easy_setopt(curl, CURLOPT_URL, endpoint.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curlWriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &write_data);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 5L);
    
    CURLcode res = curl_easy_perform(curl);
    
    std::string response;
    if (res == CURLE_OK && write_data.data) {
        response = std::string(write_data.data, write_data.size);
    } else {
        LOG_ERROR("CURL error: " + std::string(curl_easy_strerror(res)));
    }
    
    std::free(write_data.data);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    
    return response;
}

} // namespace orderbook_bot

