#include "config/config.hpp"
#include "exchange/exchange_factory.hpp"
#include "telegram/telegram_bot.hpp"
#include "utils/logger.hpp"
#include "utils/error_handler.hpp"
#include <iostream>
#include <thread>
#include <chrono>
#include <atomic>
#include <csignal>

namespace orderbook_bot {

std::atomic<bool> g_running{true};

void signalHandler(int signal) {
    if (signal == SIGINT || signal == SIGTERM) {
        LOG_INFO("Received shutdown signal, stopping...");
        g_running = false;
    }
}

int main(int argc, char* argv[]) {
    // Обработка сигналов
    std::signal(SIGINT, signalHandler);
    std::signal(SIGTERM, signalHandler);

    // Загрузка конфигурации
    Config config;
    
    // Попытка загрузить из файла, если указан
    if (argc > 1) {
        if (!config.loadFromFile(argv[1])) {
            LOG_ERROR("Failed to load config from file: " + std::string(argv[1]));
            return 1;
        }
    } else {
        // Загрузка из переменных окружения
        if (!config.loadFromEnvironment()) {
            LOG_ERROR("Failed to load config from environment");
            return 1;
        }
    }

    if (!config.validate()) {
        LOG_ERROR("Invalid configuration");
        return 1;
    }

    config.print();

    // Инициализация логгера
    LogLevel log_level = LogLevel::INFO;
    if (config.log_level == "DEBUG") log_level = LogLevel::DEBUG;
    else if (config.log_level == "WARNING") log_level = LogLevel::WARNING;
    else if (config.log_level == "ERROR") log_level = LogLevel::ERROR;

    Logger::getInstance().initialize(log_level, config.log_file, config.log_enabled);


    // Создание биржи
    auto exchange = ExchangeFactory::createByName(config.exchange_name);
    if (!exchange) {
        LOG_ERROR("Failed to create exchange: " + config.exchange_name);
        return 1;
    }

    // Создание Telegram бота
    TelegramBot telegram_bot(config.telegram_bot_token, config.telegram_chat_id);

    // Подключение к бирже с повторными попытками
    bool connected = ErrorHandler::retryOperation(
        [&exchange]() {
            return exchange->connect();
        },
        config.max_reconnect_attempts,
        config.reconnect_delay_sec,
        "Exchange connection"
    );

    if (!connected) {
        LOG_ERROR("Failed to connect to exchange");
        return 1;
    }

    // Подписка на OrderBook
    if (!exchange->subscribeOrderBook(config.symbol)) {
        LOG_ERROR("Failed to subscribe to OrderBook");
        return 1;
    }

    LOG_INFO("OrderBook Bot started successfully");

    // Основной цикл
    auto last_send_time = std::chrono::steady_clock::now();
    
    while (g_running) {
        // Проверка подключения
        if (!exchange->isConnected()) {
            LOG_WARNING("Connection lost, attempting to reconnect...");
            ErrorHandler::handleConnectionError(
                "Connection lost",
                [&exchange]() {
                    exchange->disconnect();
                    return exchange->connect();
                },
                config.max_reconnect_attempts,
                config.reconnect_delay_sec
            );
            
            if (exchange->isConnected()) {
                exchange->subscribeOrderBook(config.symbol);
            }
        }
        auto now = std::chrono::steady_clock::now();
        auto ping_elapsed = std::chrono::duration_cast<std::chrono::seconds>(
            now - exchange->getLastPingTime()
        ).count();

        if (ping_elapsed >= 15) {
            LOG_DEBUG("WS << ping");
            exchange->sendPing();
        }

        // Обработка WebSocket сообщений происходит в отдельном потоке

        // Отправка в Telegram по интервалу
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(
            now - last_send_time).count();

        if (elapsed >= config.update_interval_sec) {
            auto orderbook = exchange->getOrderBook();
            if (orderbook && !orderbook->isEmpty()) {
                if (telegram_bot.sendOrderBook(
                    orderbook,
                    config.symbol,
                    config.tg_price_precision,
                    config.tg_quantity_precision,
                    config.tg_use_newlines,
                    config.orderbook_depth
                )) {
                    LOG_INFO("OrderBook sent to Telegram");
                } else {
                    LOG_ERROR("Failed to send OrderBook to Telegram");
                }
            } else {
                LOG_WARNING("OrderBook is empty, skipping send");
            }
            last_send_time = now;
        }

        // Небольшая задержка для снижения нагрузки на CPU
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    // Отключение
    exchange->disconnect();
    LOG_INFO("OrderBook Bot stopped");

    return 0;
}

} // namespace orderbook_bot

int main(int argc, char* argv[]) {
    return orderbook_bot::main(argc, argv);
}

