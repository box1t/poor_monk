#include "websocket/websocket_client.hpp"
#include "utils/logger.hpp"
#include <libwebsockets.h>
#include <string>
#include <thread>
#include <mutex>
#include <atomic>
#include <queue>
#include <cstring>

namespace orderbook_bot {

class WebSocketClientImpl : public WebSocketClient {
public:
    WebSocketClientImpl() 
        : context_(nullptr), wsi_(nullptr), connected_(false), 
          should_exit_(false), thread_running_(false)  {
    }

    ~WebSocketClientImpl() override {
        disconnect();
    }

    bool connect(const std::string& url) override {
        if (connected_) {
            return true;
        }

        url_ = url;
        should_exit_ = false;

        struct lws_context_creation_info info;
        std::memset(&info, 0, sizeof(info));
        info.port = CONTEXT_PORT_NO_LISTEN;
        info.protocols = protocols_;
        info.gid = -1;
        info.uid = -1;
        info.options = LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT;

        context_ = lws_create_context(&info);
        if (!context_) {
            LOG_ERROR("Failed to create WebSocket context");
            return false;
        }

        if (!parseUrl(url, host_, path_, port_, use_ssl_)) {
            LOG_ERROR("Failed to parse URL: " + url);
            lws_context_destroy(context_);
            context_ = nullptr;
            return false;
        }

        if (!connectInternal()) {
            lws_context_destroy(context_);
            context_ = nullptr;
            return false;
        }

        thread_running_ = true;
        worker_thread_ = std::thread(&WebSocketClientImpl::workerThread, this);

        return true;
    }

    void disconnect() override {
        should_exit_ = true;
        connected_ = false;

        if (context_) {
            lws_cancel_service(context_);
        }

        if (thread_running_) {
            if (worker_thread_.joinable()) {
                worker_thread_.join();
            }
            thread_running_ = false;
        }

        if (context_) {
            lws_context_destroy(context_);
            context_ = nullptr;
        }

        wsi_ = nullptr;
    }

    bool send(const std::string& message) override {
        if (!connected_ || !wsi_) {
            return false;
        }

        std::lock_guard<std::mutex> lock(send_queue_mutex_);
        send_queue_.push(message);
        lws_callback_on_writable(wsi_);
        return true;
    }

    bool isConnected() const override {
        return connected_ && wsi_ != nullptr;
    }

    void setMessageCallback(MessageCallback callback) override {
        message_callback_ = std::move(callback);
    }

    void setErrorCallback(ErrorCallback callback) override {
        error_callback_ = std::move(callback);
    }

    void poll() override {
        if (context_ && connected_) {
            lws_service(context_, 0);
        }
    }

private:
    static int callback_http(struct lws*, enum lws_callback_reasons,
                             void*, void*, size_t) {
        return 0;
    }

    static int callback_ws(struct lws* wsi, enum lws_callback_reasons reason,
                          void* user, void* in, size_t len) {
        WebSocketClientImpl* client = nullptr;
        
        if (reason == LWS_CALLBACK_CLIENT_ESTABLISHED || reason == LWS_CALLBACK_CLIENT_CONNECTION_ERROR) {
            void* ud = lws_wsi_user(wsi);
            client = static_cast<WebSocketClientImpl*>(ud);
        } else {
            client = static_cast<WebSocketClientImpl*>(user);
        }
        
        if (!client) {
            return -1;
        }

        switch (reason) {
            case LWS_CALLBACK_CLIENT_ESTABLISHED:
                client->connected_ = true;
                client->wsi_ = wsi;
                LOG_INFO("WebSocket connected");
                {
                    std::lock_guard<std::mutex> lock(client->send_queue_mutex_);
                    while (!client->send_queue_.empty()) {
                        lws_callback_on_writable(wsi);
                    }
                }
                break;

            case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
                client->connected_ = false;
                client->wsi_ = nullptr;
                if (client->error_callback_) {
                    client->error_callback_("Connection error");
                }
                LOG_ERROR("WebSocket connection error");
                break;

            case LWS_CALLBACK_CLOSED:
                client->connected_ = false;
                client->wsi_ = nullptr;
                LOG_INFO("WebSocket closed");
                break;
            case LWS_CALLBACK_CLIENT_RECEIVE:
                if (!in || len == 0) break;

                if (lws_is_first_fragment(wsi)) {
                    client->recv_buffer_.clear();
                }

                client->recv_buffer_.append(static_cast<const char*>(in), len);

                if (lws_is_final_fragment(wsi)) {
                    if (client->message_callback_) {
                        client->message_callback_(client->recv_buffer_);
                    }
                    client->recv_buffer_.clear();
                }
                break;
            case LWS_CALLBACK_CLIENT_WRITEABLE:
                {
                    std::lock_guard<std::mutex> lock(client->send_queue_mutex_);
                    if (!client->send_queue_.empty()) {
                        std::string msg = client->send_queue_.front();
                        client->send_queue_.pop();

                        unsigned char* buf = new unsigned char[LWS_PRE + msg.size() + 1];
                        std::memcpy(&buf[LWS_PRE], msg.c_str(), msg.size());
                        buf[LWS_PRE + msg.size()] = '\0';

                        int n = lws_write(wsi, &buf[LWS_PRE], msg.size(), LWS_WRITE_TEXT);
                        delete[] buf;

                        if (n < 0) {
                            LOG_ERROR("WebSocket write error");
                        } else if (!client->send_queue_.empty()) {
                            lws_callback_on_writable(wsi);
                        }
                    }
                }
                break;

            default:
                break;
        }

        return 0;
    }

    bool parseUrl(const std::string& url, std::string& host, std::string& path,
                  int& port, bool& ssl) {
        if (url.find("wss://") == 0) {
            ssl = true;
            port = 443;
            size_t start = 6;
            size_t slash = url.find('/', start);
            if (slash == std::string::npos) {
                host = url.substr(start);
                path = "/";
            } else {
                host = url.substr(start, slash - start);
                path = url.substr(slash);
            }
        } else if (url.find("ws://") == 0) {
            ssl = false;
            port = 80;
            size_t start = 5;
            size_t slash = url.find('/', start);
            if (slash == std::string::npos) {
                host = url.substr(start);
                path = "/";
            } else {
                host = url.substr(start, slash - start);
                path = url.substr(slash);
            }
        } else {
            return false;
        }

        size_t colon = host.find(':');
        if (colon != std::string::npos) {
            port = std::stoi(host.substr(colon + 1));
            host = host.substr(0, colon);
        }

        return true;
    }

    bool connectInternal() {
        struct lws_client_connect_info cci;
        std::memset(&cci, 0, sizeof(cci));
        cci.context = context_;
        cci.address = host_.c_str();
        cci.port = port_;
        cci.path = path_.c_str();
        cci.host = host_.c_str();
        cci.origin = host_.c_str();
        cci.ssl_connection = use_ssl_ ? LCCSCF_USE_SSL | LCCSCF_ALLOW_SELFSIGNED : 0;
        lws_set_log_level(LLL_USER | LLL_ERR | LLL_WARN | LLL_NOTICE | LLL_INFO | LLL_DEBUG, nullptr);

        cci.protocol = protocols_[1].name;
        cci.ssl_connection = use_ssl_ ? LCCSCF_USE_SSL : 0;
        cci.userdata = this;
        cci.pwsi = &wsi_;

        wsi_ = lws_client_connect_via_info(&cci);

        if (!wsi_) {
            LOG_ERROR("Failed to initiate WebSocket connection to " + url_);
            return false;
        }
        return true;
    }

    // https://github.com/warmcat/libwebsockets/blob/main/include/libwebsockets/lws-callbacks.h#L525
    static std::string wsReasonToString(int reason) {
        switch(reason) {
            case 1: return "LWS_CALLBACK_ESTABLISHED";
            case 2: return "LWS_CALLBACK_CLIENT_CONNECTION_ERROR";
            case 3: return "LWS_CALLBACK_CLIENT_ESTABLISHED";
            case 19: return "LWS_CALLBACK_CLOSED";
            case 8: return "LWS_CALLBACK_CLIENT_RECEIVE";
            case 24: return "LWS_CALLBACK_CLIENT_CLOSED";
            case 29: return "LWS_CALLBACK_WSI_CREATE";
            case 44: return "LWS_CALLBACK_ESTABLISHED_CLIENT_HTTP";
            case 58: return "LWS_CALLBACK_OPENSSL_PERFORM_SERVER_CERT_VERIFICATION";
            case 71: return "LWS_CALLBACK_CLIENT_WRITEABLE";
            case 75: return "LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER";
            case 76: return "LWS_CALLBACK_CLIENT_CONFIRM_EXTENSION_SUPPORTED";
            case 80: return "LWS_CALLBACK_CLIENT_HTTP_WRITEABLE";
            case 85: return "LWS_CALLBACK_CLIENT_HTTP_BIND_PROTOCOL";
            case 105: return "LWS_CALLBACK_CONNECTING";
            default:
                return "Unknown reason code: " + std::to_string(reason);
        }
    }

    void workerThread() {
        while (!should_exit_ && context_) {
            lws_service(context_, 50);
        }
    }

    static struct lws_protocols protocols_[];
    struct lws_context* context_;
    struct lws* wsi_;
    std::atomic<bool> connected_;
    std::atomic<bool> should_exit_;
    std::atomic<bool> thread_running_;
    std::string url_;
    std::string host_;
    std::string path_;
    int port_;
    bool use_ssl_;
    MessageCallback message_callback_;
    ErrorCallback error_callback_;
    std::thread worker_thread_;
    std::mutex send_queue_mutex_;
    std::queue<std::string> send_queue_;
    std::string recv_buffer_;
};

struct lws_protocols WebSocketClientImpl::protocols_[] = {
    { "http-only", callback_http, 0, 0 },
    { "wss", callback_ws, 0, 0 },
    { nullptr, nullptr, 0, 0 }
};

std::unique_ptr<WebSocketClient> createWebSocketClient() {
    return std::make_unique<WebSocketClientImpl>();
}

} // namespace orderbook_bot
