#include "exchange/mexc_exchange.hpp"
#include "utils/logger.hpp"
#include "websocket/websocket_client.hpp"
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <chrono>
#include <thread>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

namespace orderbook_bot {
MexcExchange::MexcExchange() : connected_(false) {
    exchange_name_ = "MEXC";
    orderbook_ = std::make_shared<OrderBook>();
    ws_client_ = createWebSocketClient();
    
    if (ws_client_) {
        ws_client_->setMessageCallback([this](const std::string& msg) {
            this->onMessage(msg);
        });
        ws_client_->setErrorCallback([this](const std::string& error) {
            LOG_ERROR("WebSocket error: " + error);
            this->connected_.store(false, std::memory_order_release);
        });
    }
}

MexcExchange::~MexcExchange() {
    disconnect();
}

std::chrono::steady_clock::time_point MexcExchange::getLastPingTime() {
    return last_ping_time_;
}

bool MexcExchange::connect() {
    if (!ws_client_) {
        LOG_ERROR("WebSocket client not initialized");
        return false;
    }

    LOG_INFO("Connecting to MEXC WebSocket: " + std::string(WS_URL));
    if (!ws_client_->connect(WS_URL)) {
        LOG_ERROR("Failed to create WebSocket connection");
        return false;
    }

    // Ждём handshake
    int wait_ms = 0;
    const int timeout_ms = 5000; // 5 секунд
    while (!ws_client_->isConnected() && wait_ms < timeout_ms) {
        ws_client_->poll();
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        wait_ms += 50;
    }

    if (!ws_client_->isConnected()) {
        LOG_ERROR("WebSocket handshake not completed in time");
        return false;
    }

    LOG_INFO("Connected to MEXC WebSocket");
    connected_.store(true, std::memory_order_release);
    last_ping_time_ = std::chrono::steady_clock::now();
    return true;
}

void MexcExchange::sendPing() {
    if (!ws_client_ || !ws_client_->isConnected()) {
        return;
    }

    ws_client_->send(R"({"method":"ping"})");
    last_ping_time_ = std::chrono::steady_clock::now();

    LOG_DEBUG("MEXC ping sent");
}

void MexcExchange::disconnect() {
    if (ws_client_) ws_client_->disconnect();
    connected_.store(false, std::memory_order_release);
    LOG_INFO("Disconnected from MEXC");
}

bool MexcExchange::subscribeOrderBook(const std::string& symbol) {
    if (!connected_.load(std::memory_order_acquire) || !ws_client_) {
        LOG_ERROR("Not connected to MEXC");
        return false;
    }

    std::string msg = 
        R"({"method":"sub.depth","param":{"symbol":")" + symbol + R"("}})";

    LOG_INFO("MEXC Futures subscribe depth: " + msg);

    if (!ws_client_->isConnected()) {
        LOG_ERROR("WebSocket not fully connected yet");
        return false;
    }
    return ws_client_->send(msg);
}


std::shared_ptr<OrderBook> MexcExchange::getOrderBook() {
    return orderbook_;
}

bool MexcExchange::isConnected() const {
    return connected_.load(std::memory_order_acquire) && ws_client_ && ws_client_->isConnected();
}

std::string MexcExchange::getName() const {
    return exchange_name_;
}

void MexcExchange::onMessage(const std::string& message) {
    if (message.find("pong") != std::string::npos) {
        LOG_DEBUG("MEXC pong received: " + message);
        return;
    }

    LOG_INFO("MEXC Futures message: " + message);

    if (message.find("\"push.depth\"") == std::string::npos) {
        return;
    }

    parseOrderBookMessage(message);
}

void MexcExchange::parseOrderBookMessage(const std::string& message) {
    try {
        json j = json::parse(message);
        if (!j.contains("data")) return;
        const auto& data = j["data"];

        if (!data.contains("bids") || !data.contains("asks")) return;

        static thread_local Order bids_buffer[MAX_ORDERBOOK_DEPTH];
        static thread_local Order asks_buffer[MAX_ORDERBOOK_DEPTH];

        size_t bids_count = orderbook_->getBidsCount();
        size_t asks_count = orderbook_->getAsksCount();
        orderbook_->getTopBids(bids_buffer, bids_count);
        orderbook_->getTopAsks(asks_buffer, asks_count);

        auto applyDelta = [](Order* side, size_t& count, const json& arr, bool is_bid){
            for (const auto& lvl : arr) {
                if (!lvl.is_array() || lvl.size() < 3) continue;
                double price = lvl[0].get<double>();
                double qty   = lvl[2].get<double>();
                if (qty <= 0.0) {
                    // удалить уровень, если есть
                    for (size_t i = 0; i < count; ++i) {
                        if (side[i].price == price) {
                            std::move(side + i + 1, side + count, side + i);
                            --count;
                            break;
                        }
                    }
                } else {
                    // обновляем или добавляем уровни стакана
                    bool updated = false;
                    for (size_t i = 0; i < count; ++i) {
                        if (side[i].price == price) {
                            side[i].quantity = qty;
                            updated = true;
                            break;
                        }
                    }
                    if (!updated && count < MAX_ORDERBOOK_DEPTH) {
                        side[count++] = {price, qty};
                    }
                }
            }

            size_t top_n = std::min((size_t)5, count);
            if (is_bid) std::partial_sort(side, side + top_n, side + count, std::greater<Order>());
            else        std::partial_sort(side, side + top_n, side + count, std::less<Order>());
        };

        applyDelta(bids_buffer, bids_count, data["bids"], true);
        applyDelta(asks_buffer, asks_count, data["asks"], false);

        orderbook_->setBids(bids_buffer, bids_count);
        orderbook_->setAsks(asks_buffer, asks_count);
        orderbook_->setTimestamp(
            std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count()
        );

        LOG_DEBUG("OrderBook updated: bids=" + std::to_string(bids_count) +
                  " asks=" + std::to_string(asks_count));

    } catch (const std::exception& e) {
        LOG_ERROR("OrderBook JSON parse error: " + std::string(e.what()));
    }
}


} // namespace orderbook_bot

