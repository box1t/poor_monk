#include "exchange/exchange_factory.hpp"
#include "exchange/mexc_exchange.hpp"
#include "utils/logger.hpp"
#include <algorithm>
#include <cctype>

namespace orderbook_bot {

std::unique_ptr<ExchangeBase> ExchangeFactory::create(ExchangeType type) {
    switch (type) {
        case ExchangeType::MEXC:
            return std::make_unique<MexcExchange>();
        case ExchangeType::UNKNOWN:
        default:
            LOG_ERROR("Unknown exchange type");
            return nullptr;
    }
}

std::unique_ptr<ExchangeBase> ExchangeFactory::createByName(const std::string& name) {
    ExchangeType type = stringToType(name);
    if (type == ExchangeType::UNKNOWN) {
        LOG_ERROR("Unsupported exchange: " + name);
        return nullptr;
    }
    return create(type);
}

ExchangeFactory::ExchangeType ExchangeFactory::stringToType(const std::string& name) {
    std::string upper_name = name;
    std::transform(upper_name.begin(), upper_name.end(), upper_name.begin(), ::toupper);
    
    if (upper_name == "MEXC") {
        return ExchangeType::MEXC;
    }
    
    return ExchangeType::UNKNOWN;
}

} // namespace orderbook_bot

