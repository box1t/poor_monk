#include "utils/logger.hpp"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <ctime>

namespace orderbook_bot {

Logger& Logger::getInstance() {
    static Logger instance;
    return instance;
}

Logger::Logger() noexcept 
    : current_level_(LogLevel::INFO), use_file_(false), enabled_(true) {
}

Logger::~Logger() {
    if (log_file_ && log_file_->is_open()) {
        log_file_->close();
    }
}

void Logger::initialize(LogLevel level, const std::string& log_file, bool enabled) {
    current_level_ = level;
    enabled_ = enabled;

    if (!log_file.empty() && enabled_) {
        log_file_ = std::make_unique<std::ofstream>(log_file, std::ios::app);
        use_file_ = log_file_->is_open();
        if (!use_file_) {
            std::cerr << "Warning: Cannot open log file: " << log_file << std::endl;
        }
    }
}

void Logger::log(LogLevel level, const std::string& message) {
    if (!enabled_ || level < current_level_) {
        return;
    }

    std::ostringstream oss;
    oss << "[" << getCurrentTime() << "] "
        << "[" << levelToString(level) << "] "
        << message << std::endl;

    std::string log_message = oss.str();

    if (use_file_ && log_file_ && log_file_->is_open()) {
        *log_file_ << log_message;
        log_file_->flush();
    } else {
        std::cout << log_message;
        std::cout.flush();
    }
}

void Logger::debug(const std::string& message) { log(LogLevel::DEBUG, message); }
void Logger::info(const std::string& message) { log(LogLevel::INFO, message); }
void Logger::warning(const std::string& message) { log(LogLevel::WARNING, message); }
void Logger::error(const std::string& message) { log(LogLevel::ERROR, message); }

void Logger::setLevel(LogLevel level) { current_level_ = level; }
void Logger::setEnabled(bool enabled) { enabled_ = enabled; }

std::string Logger::levelToString(LogLevel level) {
    switch (level) {
        case LogLevel::DEBUG:   return "DEBUG";
        case LogLevel::INFO:    return "INFO";
        case LogLevel::WARNING: return "WARNING";
        case LogLevel::ERROR:   return "ERROR";
        default:                return "UNKNOWN";
    }
}

std::string Logger::getCurrentTime() {
    auto now = std::time(nullptr);
    auto tm = *std::localtime(&now);
    
    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

} // namespace orderbook_bot
