#include "utils/error_handler.hpp"
#include "utils/logger.hpp"
#include <thread>
#include <chrono>

namespace orderbook_bot {

bool ErrorHandler::retryOperation(RetryCallback operation,
                                  uint32_t max_attempts,
                                  uint32_t delay_sec,
                                  const std::string& operation_name) {
    for (uint32_t attempt = 1; attempt <= max_attempts; ++attempt) {
        LOG_INFO(operation_name + " - Attempt " + std::to_string(attempt) + "/" + std::to_string(max_attempts));
        
        if (operation()) {
            LOG_INFO(operation_name + " - Success");
            return true;
        }
        
        if (attempt < max_attempts) {
            LOG_WARNING(operation_name + " - Failed, retrying in " + std::to_string(delay_sec) + " seconds...");
            std::this_thread::sleep_for(std::chrono::seconds(delay_sec));
        }
    }
    
    LOG_ERROR(operation_name + " - Failed after " + std::to_string(max_attempts) + " attempts");
    return false;
}

bool ErrorHandler::handleConnectionError(const std::string& error_message,
                                         RetryCallback reconnect_callback,
                                         uint32_t max_attempts,
                                         uint32_t delay_sec) {
    LOG_ERROR("Connection error: " + error_message);
    return retryOperation(reconnect_callback, max_attempts, delay_sec, "Reconnection");
}

} // namespace orderbook_bot

