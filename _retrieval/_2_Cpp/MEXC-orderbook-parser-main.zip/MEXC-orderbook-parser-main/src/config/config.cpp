#include "config/config.hpp"
#include "utils/logger.hpp"
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <cstring>

namespace orderbook_bot {

static const char* findJsonValue(const char* str, const char* key, std::string& value) {
    std::string search = std::string("\"") + key + "\"";
    const char* pos = std::strstr(str, search.c_str());
    if (!pos) return nullptr;
    
    pos += search.length();
    while (*pos && (*pos == ' ' || *pos == ':')) ++pos;
    
    if (*pos == '"') {
        ++pos;
        const char* end = pos;
        while (*end && *end != '"') {
            if (*end == '\\' && *(end + 1)) end += 2;
            else ++end;
        }
        value = std::string(pos, end - pos);
        return end + 1;
    } else if ((*pos >= '0' && *pos <= '9') || *pos == '-' || *pos == '.') {
        const char* end = pos;
        while (*end && ((*end >= '0' && *end <= '9') || *end == '.')) ++end;
        value = std::string(pos, end - pos);
        return end;
    }
    return nullptr;
}

static uint32_t fastAtoi(const char* str) {
    uint32_t result = 0;
    while (*str >= '0' && *str <= '9') {
        result = result * 10 + (*str - '0');
        ++str;
    }
    return result;
}


Config::Config() 
    : tg_price_precision(2),
      tg_quantity_precision(2),
      tg_use_newlines(true),
      update_interval_sec(60),
      orderbook_depth(5),
      reconnect_delay_sec(5),
      max_reconnect_attempts(10),
      log_enabled(true),
      log_level("INFO")
{}

Config::~Config() {}


bool Config::loadFromFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        LOG_ERROR("Cannot open config file: " + filename);
        return false;
    }

    std::ostringstream buffer;
    buffer << file.rdbuf();
    file.close();
    
    std::string content = buffer.str();
    const char* str = content.c_str();
    
    std::string temp;

    const char* p = findJsonValue(str, "name", temp);
    if (p) exchange_name = temp;

    p = findJsonValue(str, "symbol", temp);
    if (p) symbol = temp;

    p = findJsonValue(str, "bot_token", temp);
    if (p) telegram_bot_token = temp;

    p = findJsonValue(str, "chat_id", temp);
    if (p) telegram_chat_id = temp;

    p = findJsonValue(str, "update_interval_sec", temp);
    if (p) update_interval_sec = fastAtoi(temp.c_str());

    p = findJsonValue(str, "orderbook_depth", temp);
    if (p) orderbook_depth = static_cast<int>(fastAtoi(temp.c_str()));

    p = findJsonValue(str, "reconnect_delay_sec", temp);
    if (p) reconnect_delay_sec = fastAtoi(temp.c_str());

    p = findJsonValue(str, "max_reconnect_attempts", temp);
    if (p) max_reconnect_attempts = fastAtoi(temp.c_str());

    p = findJsonValue(str, "level", temp);
    if (p) log_level = temp;

    p = findJsonValue(str, "file", temp);
    if (p) log_file = temp;

    p = findJsonValue(str, "enabled", temp);
    if (p) log_enabled = (temp == "true");

    p = findJsonValue(str, "tg_price_precision", temp);
    if (p) tg_price_precision = std::stoi(temp);

    p = findJsonValue(str, "tg_quantity_precision", temp);
    if (p) tg_quantity_precision = std::stoi(temp);

    p = findJsonValue(str, "tg_use_newlines", temp);
    if (p) tg_use_newlines = (temp == "true");

    return validate();
}

bool Config::loadFromEnvironment() {
    const char* env;
    if ((env = std::getenv("EXCHANGE_NAME"))) exchange_name = env;
    if ((env = std::getenv("SYMBOL"))) symbol = env;
    if ((env = std::getenv("TELEGRAM_BOT_TOKEN"))) telegram_bot_token = env;
    if ((env = std::getenv("TELEGRAM_CHAT_ID"))) telegram_chat_id = env;
    if ((env = std::getenv("UPDATE_INTERVAL_SEC"))) update_interval_sec = std::stoul(env);
    if ((env = std::getenv("ORDERBOOK_DEPTH"))) orderbook_depth = std::stoi(env);

    if ((env = std::getenv("LOG_ENABLED"))) log_enabled = (std::string(env) == "1" || std::string(env) == "true");
    if ((env = std::getenv("LOG_LEVEL"))) log_level = env;
    if ((env = std::getenv("LOG_FILE"))) log_file = env;

    if ((env = std::getenv("TG_PRICE_PRECISION"))) tg_price_precision = std::stoi(env);
    if ((env = std::getenv("TG_QUANTITY_PRECISION"))) tg_quantity_precision = std::stoi(env);
    if ((env = std::getenv("TG_USE_NEWLINES"))) tg_use_newlines = (std::string(env) == "1" || std::string(env) == "true");

    return validate();
}

bool Config::validate() const {
    if (exchange_name.empty()) { LOG_ERROR("Exchange name is not set"); return false; }
    if (symbol.empty()) { LOG_ERROR("Symbol is not set"); return false; }
    if (telegram_bot_token.empty()) { LOG_ERROR("Telegram bot token is not set"); return false; }
    if (telegram_chat_id.empty()) { LOG_ERROR("Telegram chat ID is not set"); return false; }
    if (update_interval_sec == 0) { LOG_ERROR("Update interval must be > 0"); return false; }
    if (orderbook_depth <= 0) { LOG_ERROR("OrderBook depth must be > 0"); return false; }
    if (tg_price_precision < 0) { LOG_ERROR("TG price precision must be >= 0"); return false; }
    if (tg_quantity_precision < 0) { LOG_ERROR("TG quantity precision must be >= 0"); return false; }
    return true;
}

void Config::print() const {
    LOG_INFO("Configuration:");
    LOG_INFO("  Exchange: " + exchange_name);
    LOG_INFO("  Symbol: " + symbol);
    LOG_INFO("  Update interval: " + std::to_string(update_interval_sec) + " sec");
    LOG_INFO("  OrderBook depth: " + std::to_string(orderbook_depth));
    LOG_INFO("  Log enabled: " + std::string(log_enabled ? "true" : "false"));
    LOG_INFO("  Log level: " + log_level);
    LOG_INFO("  TG price precision: " + std::to_string(tg_price_precision));
    LOG_INFO("  TG quantity precision: " + std::to_string(tg_quantity_precision));
    LOG_INFO("  TG use newlines: " + std::string(tg_use_newlines ? "true" : "false"));
}

} // namespace orderbook_bot
