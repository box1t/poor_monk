#pragma once

#include <string>
#include <fstream>
#include <memory>

namespace orderbook_bot {

/**
 * @brief Уровни логирования
 */
enum class LogLevel {
    DEBUG = 0,
    INFO = 1,
    WARNING = 2,
    ERROR = 3
};

/**
 * @brief Класс для логирования
 */
class Logger {
public:
    static Logger& getInstance();

    void initialize(LogLevel level, const std::string& log_file = "", bool enabled = true);
    void log(LogLevel level, const std::string& message);
    void debug(const std::string& message);
    void info(const std::string& message);
    void warning(const std::string& message);
    void error(const std::string& message);
    void setLevel(LogLevel level);
    void setEnabled(bool enabled);

private:
    Logger() noexcept;
    ~Logger();

    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;

    std::string levelToString(LogLevel level);
    std::string getCurrentTime();

    LogLevel current_level_;
    std::unique_ptr<std::ofstream> log_file_;
    bool use_file_;
    bool enabled_;
};

// Так удобнее)
#define LOG_DEBUG(msg) Logger::getInstance().debug(msg)
#define LOG_INFO(msg) Logger::getInstance().info(msg)
#define LOG_WARNING(msg) Logger::getInstance().warning(msg)
#define LOG_ERROR(msg) Logger::getInstance().error(msg)

} // namespace orderbook_bot

