#pragma once

#include <string>
#include <functional>

namespace orderbook_bot {

/**
 * @brief Класс для обработки ошибок и переподключений
 */
class ErrorHandler {
public:
    using RetryCallback = std::function<bool()>;

    static bool retryOperation(RetryCallback operation,
                               uint32_t max_attempts,
                               uint32_t delay_sec,
                               const std::string& operation_name);

    static bool handleConnectionError(const std::string& error_message,
                                      RetryCallback reconnect_callback,
                                      uint32_t max_attempts,
                                      uint32_t delay_sec);
};

} // namespace orderbook_bot

