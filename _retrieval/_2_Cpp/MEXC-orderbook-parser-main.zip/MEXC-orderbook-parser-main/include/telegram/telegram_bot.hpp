#pragma once

#include <string>
#include <memory>
#include "../orderbook/orderbook.hpp"

namespace orderbook_bot {

/**
 * @brief Класс для отправки сообщений в Telegram
 */
class TelegramBot {
public:
    TelegramBot(const std::string& bot_token, const std::string& chat_id);
    ~TelegramBot();
    bool sendOrderBook(std::shared_ptr<OrderBook> orderbook, 
                       const std::string& symbol,
                       int tg_price_precision,
                       int tg_quantity_precision,
                       bool tg_use_newlines,
                       int depth = 5);

    bool sendMessage(const std::string& message);

    static std::string formatOrderBook(std::shared_ptr<OrderBook> orderbook,
                                       const std::string& symbol,
                                       int tg_price_precision,
                                       int tg_quantity_precision,
                                       bool tg_use_newlines,
                                       int depth);

private:
    std::string httpPost(const std::string& endpoint, const std::string& data);

    std::string bot_token_;
    std::string chat_id_;
    static constexpr const char* API_URL = "https://api.telegram.org/bot";
};

} // namespace orderbook_bot

