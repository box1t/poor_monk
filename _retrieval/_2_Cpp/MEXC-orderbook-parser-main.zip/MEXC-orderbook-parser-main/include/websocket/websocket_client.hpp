#pragma once

#include <string>
#include <functional>
#include <memory>

namespace orderbook_bot {

/**
 * @brief Базовый класс для WebSocket клиента
 */
class WebSocketClient {
public:
    using MessageCallback = std::function<void(const std::string&)>;
    using ErrorCallback = std::function<void(const std::string&)>;

    virtual ~WebSocketClient() = default;

    virtual bool connect(const std::string& url) = 0;

    virtual void disconnect() = 0;
    virtual bool send(const std::string& message) = 0;
    virtual bool isConnected() const = 0;
    virtual void setMessageCallback(MessageCallback callback) = 0;
    virtual void setErrorCallback(ErrorCallback callback) = 0;
    virtual void poll() = 0;
};

std::unique_ptr<WebSocketClient> createWebSocketClient();

} // namespace orderbook_bot

