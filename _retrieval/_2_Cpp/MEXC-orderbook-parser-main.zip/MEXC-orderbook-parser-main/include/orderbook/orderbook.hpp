#pragma once

#include <cstdint>
#include <cstring>
#include <algorithm>

namespace orderbook_bot {

static constexpr size_t MAX_ORDERBOOK_DEPTH = 1024;
static constexpr size_t CACHE_LINE_SIZE = 64;

struct alignas(CACHE_LINE_SIZE) Order {
    double price;
    double quantity;
    
    Order() noexcept : price(0.0), quantity(0.0) {}
    Order(double p, double q) noexcept : price(p), quantity(q) {}
    
    bool operator>(const Order& other) const noexcept { return price > other.price; }
    bool operator<(const Order& other) const noexcept { return price < other.price; }
};

class OrderBook {
public:
    OrderBook() noexcept : bids_count_(0), asks_count_(0), timestamp_(0) {
        std::memset(bids_, 0, sizeof(bids_));
        std::memset(asks_, 0, sizeof(asks_));
    }
    
    ~OrderBook() = default;
    
    OrderBook(const OrderBook&) = default;
    OrderBook& operator=(const OrderBook&) = default;
    OrderBook(OrderBook&&) noexcept = default;
    OrderBook& operator=(OrderBook&&) noexcept = default;

    void setBids(const Order* bids, size_t count) noexcept {
        bids_count_ = std::min(count, MAX_ORDERBOOK_DEPTH);
        if (bids && bids_count_ > 0) {
            std::memcpy(bids_, bids, bids_count_ * sizeof(Order));
            std::sort(bids_, bids_ + bids_count_, std::greater<Order>());
        }
    }

    void setAsks(const Order* asks, size_t count) noexcept {
        asks_count_ = std::min(count, MAX_ORDERBOOK_DEPTH);
        if (asks && asks_count_ > 0) {
            std::memcpy(asks_, asks, asks_count_ * sizeof(Order));
            std::sort(asks_, asks_ + asks_count_, std::less<Order>());
        }
    }

    const Order* getBids() const noexcept { return bids_; }
    const Order* getAsks() const noexcept { return asks_; }
    size_t getBidsCount() const noexcept { return bids_count_; }
    size_t getAsksCount() const noexcept { return asks_count_; }

    void getTopBids(Order* out, size_t n) const noexcept {
        size_t count = std::min(n, bids_count_);
        if (out && count > 0) {
            std::memcpy(out, bids_, count * sizeof(Order));
        }
    }

    void getTopAsks(Order* out, size_t n) const noexcept {
        size_t count = std::min(n, asks_count_);
        if (out && count > 0) {
            std::memcpy(out, asks_, count * sizeof(Order));
        }
    }

    bool isEmpty() const noexcept {
        return bids_count_ == 0 && asks_count_ == 0;
    }

    void clear() noexcept {
        bids_count_ = 0;
        asks_count_ = 0;
        timestamp_ = 0;
        std::memset(bids_, 0, sizeof(bids_));
        std::memset(asks_, 0, sizeof(asks_));
    }

    void setTimestamp(uint64_t timestamp) noexcept { timestamp_ = timestamp; }
    uint64_t getTimestamp() const noexcept { return timestamp_; }

private:
    alignas(CACHE_LINE_SIZE) Order bids_[MAX_ORDERBOOK_DEPTH];
    alignas(CACHE_LINE_SIZE) Order asks_[MAX_ORDERBOOK_DEPTH];
    size_t bids_count_;
    size_t asks_count_;
    uint64_t timestamp_;
};

} // namespace orderbook_bot

