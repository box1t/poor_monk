#pragma once

#include <string>
#include <memory>
#include "../orderbook/orderbook.hpp"

namespace orderbook_bot {

/**
 * @brief Базовый класс для работы с биржами
 */
class ExchangeBase {
public:
    virtual ~ExchangeBase() = default;

    /**
     * @brief Подключение к WebSocket API биржи
     * @return true если подключение успешно
     */
    virtual bool connect() = 0;

    /**
     * @brief Отключение от WebSocket API
     */
    virtual void disconnect() = 0;

    /**
     * @brief Подписка на OrderBook для указанной торговой пары
     * @return true если подписка успешна
     */
    virtual bool subscribeOrderBook(const std::string& symbol) = 0;

    /**
     * @brief Получение текущего OrderBook
     * @return Указатель на OrderBook или nullptr если данных нет
     */
    virtual std::shared_ptr<OrderBook> getOrderBook() = 0;

    virtual bool isConnected() const = 0;

    virtual std::string getName() const = 0;

    virtual void sendPing() = 0;
    virtual std::chrono::steady_clock::time_point getLastPingTime() = 0;

    /**
     * @brief Обработка входящих сообщений (вызывается из WebSocket клиента)
     * @param message Сообщение от биржи
     */
    virtual void onMessage(const std::string& message) = 0;

protected:
    std::string exchange_name_;
    std::string current_symbol_;
    std::shared_ptr<OrderBook> orderbook_;
};

} // namespace orderbook_bot

