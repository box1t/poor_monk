#pragma once

#include "exchange_base.hpp"
#include <string>
#include <memory>

namespace orderbook_bot {

/**
 * @brief Фабрика для создания экземпляров бирж
 */
class ExchangeFactory {
public:
    enum class ExchangeType {
        UNKNOWN,
        MEXC,
        // Можно добавить другие биржи
    };

    /**
     * @brief Создание экземпляра биржи
     * @param type Тип биржи
     * @return Указатель на биржу
     */
    static std::unique_ptr<ExchangeBase> create(ExchangeType type);

    /**
     * @brief Создание биржи по имени
     * @param name Имя биржи (например, "MEXC")
     * @return Указатель на биржу или nullptr если биржа не поддерживается
     */
    static std::unique_ptr<ExchangeBase> createByName(const std::string& name);

    /**
     * @brief Преобразование строки в тип биржи
     * @param name Имя биржи
     * @return Тип биржи
     */
    static ExchangeType stringToType(const std::string& name);
};

} // namespace orderbook_bot

