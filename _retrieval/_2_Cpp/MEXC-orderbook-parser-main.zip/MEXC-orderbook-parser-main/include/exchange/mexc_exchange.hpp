#pragma once

#include "exchange_base.hpp"
#include "../websocket/websocket_client.hpp"
#include <memory>
#include <atomic>

namespace orderbook_bot {

/**
 * @brief Реализация для биржи MEXC
 */
class MexcExchange : public ExchangeBase {
public:
    MexcExchange();
    ~MexcExchange() override;

    bool connect() override;
    void disconnect() override;
    bool subscribeOrderBook(const std::string& symbol) override;
    std::shared_ptr<OrderBook> getOrderBook() override;
    bool isConnected() const override;
    std::string getName() const override;
    void onMessage(const std::string& message) override;
    void sendPing() override;
    std::chrono::steady_clock::time_point getLastPingTime() override;

private:
    /**
     * @brief Парсинг сообщения OrderBook от MEXC
     * @param message JSON сообщение
     */
    void parseOrderBookMessage(const std::string& message);

    void applyOrderBookUpdate(const std::vector<Order>&, const std::vector<Order>&);

    std::unique_ptr<WebSocketClient> ws_client_;
    std::atomic<bool> connected_;
    std::string ws_buffer_;
    static constexpr const char* WS_URL = "wss://contract.mexc.com/edge";
    std::chrono::steady_clock::time_point last_ping_time_;
};

} // namespace orderbook_bot

