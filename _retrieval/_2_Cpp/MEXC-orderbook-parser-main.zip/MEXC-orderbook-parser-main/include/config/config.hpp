#pragma once

#include <string>
#include <cstdint>

namespace orderbook_bot {

class Config {
public:
    Config();
    ~Config();

    bool loadFromFile(const std::string& filename);
    bool loadFromEnvironment();

    std::string exchange_name;      // Имя биржи (например, "MEXC")
    std::string symbol;             // Торговая пара (например, "PEPEUSDT")

    std::string telegram_bot_token; // Токен Telegram бота
    std::string telegram_chat_id;   // ID чата для отправки сообщений
    int tg_price_precision = 2;     // Количество знаков после запятой для цены
    int tg_quantity_precision = 2;  // Количество знаков после запятой для объема
    bool tg_use_newlines = true;    // Разделять цену и объем переводом строки

    uint32_t update_interval_sec = 60;   // Интервал отправки в Telegram (секунды)
    int orderbook_depth = 5;             // Глубина стакана (кол-во уровней)
    uint32_t reconnect_delay_sec = 5;    // Задержка перед переподключением (секунды)
    uint32_t max_reconnect_attempts = 10;// Максимальное число попыток переподключения

    bool log_enabled = true;        // Включить/выключить логирование
    std::string log_level = "INFO"; // Уровень логирования
    std::string log_file;           // Файл для логов (пустое = stdout)

    bool validate() const;
    void print() const;
};

} // namespace orderbook_bot